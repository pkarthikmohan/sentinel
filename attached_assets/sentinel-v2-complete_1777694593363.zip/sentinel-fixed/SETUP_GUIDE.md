# SENTINEL v2.0 — Setup Guide (4 Laptops, Real Network)

## WHAT'S NEW IN V2
- Real packet sniffing via Scapy (detects real attacks)
- COUNTERATTACK ENGINE — when honeypot catches attacker, SENTINEL:
  1. Traceroutes to their machine
  2. Nmap scans THEIR open ports
  3. ARP fingerprints their MAC address
  4. AI generates a full threat dossier
- Cinematic UI with retaliation panel — purple mode activates during counterattack
- Glitch effect on logo, brutal animations

---

## NETWORK SETUP (do this first)

1. One person creates a **mobile hotspot** on their phone
2. All 4 laptops connect to it
3. On each laptop run: `ip a` — note the 192.168.x.x IP

---

## LAPTOP ROLES

| Laptop | Role | What runs |
|--------|------|-----------|
| 1 | SENTINEL Brain | Backend + Dashboard (projected) |
| 2 | Honeypot Server | honeypot.py |
| 3 | Attacker (Kali) | attack.py |
| 4 | spare / presenter | — |

---

## LAPTOP 1 — SENTINEL (Backend + Dashboard)

```bash
# Terminal 1 — Backend (MUST run as root for real packet sniffing)
cd sentinel-backend
pip install fastapi uvicorn websockets scapy httpx flask requests --break-system-packages
sudo python3 -m uvicorn main:app --host 0.0.0.0 --port 8000

# Terminal 2 — Dashboard
cd sentinel-dashboard
npm install
npm run dev
```

Open browser: http://localhost:5173

---

## LAPTOP 2 — HONEYPOT SERVER

```bash
cd sentinel-honeypot
pip install flask requests --break-system-packages

# Set SENTINEL_URL to Laptop 1's IP
export SENTINEL_URL=http://192.168.X.X:8000

python3 honeypot.py
```

---

## LAPTOP 3 — ATTACKER (Kali Linux)

```bash
cd sentinel-attacker
# Point at Laptop 2's IP (the honeypot)
python3 attack.py 192.168.X.X
```

The script auto-runs: nmap recon → nikto web scan → sqlmap injection → hydra brute force → directory traversal

---

## DEMO FLOW ON STAGE

1. Open SENTINEL dashboard on projector — all green, calm
2. Run `attack.py` on Kali — terminal goes red, attacks start flying
3. Dashboard lights up — threat feed scrolling, radar going aggressive
4. After 30s — click **ENGAGE HONEYPOT** on dashboard
5. Kali's attack.py probes honeypot — SENTINEL detects tools (SQLMap, Hydra, Nmap)
6. Attacker profile builds in right panel live
7. **COUNTERATTACK AUTO-FIRES** — entire border turns purple
   - Traceroute to Kali
   - Nmap scan of Kali's open ports  
   - MAC address captured
   - AI dossier generated
8. Final state: "ATTACKER FULLY EXPOSED" — red text, purple mode, full dossier

---

## IF BACKEND IS UNREACHABLE

Dashboard has built-in demo mode — hit "SIMULATE ATTACK" and "ENGAGE HONEYPOT" buttons. Full animation sequence including fake retaliation runs locally. Never fails on stage.

---

## INSTALL OLLAMA (free AI — do this now, takes 20min to download)

```bash
# On Laptop 1
curl https://ollama.ai/install.sh | sh
ollama pull mistral
```

If Ollama isn't running, the system uses preset analysis text — still looks great.
